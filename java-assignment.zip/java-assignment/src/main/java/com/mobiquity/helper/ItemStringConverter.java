package com.mobiquity.helper;

import com.mobiquity.model.Item;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class to handle the conversion of {@code Item} objects into formatted strings.
 * It provides static methods to obtain and append the representation of a list of {@code Item} objects.
 */
public class ItemStringConverter {

    /** Represents a new line. */
    public static final String NEW_LINE = "\n";
    /** Represents a brake or separator. */
    public static final String BRAKE = "-";
    /** Represents a comma separator. */
    public static final String COMMA = ",";

    /**
     * Converts a list of {@code Item} objects into a comma-separated string.
     *
     * @param result the list of {@code Item} objects to be converted.
     * @return a comma-separated string representation of the items. If the list is empty,
     *         it returns the BRAKE string.
     */
    public static String toResultString(List<Item> result) {

        if(CollectionUtils.isEmpty(result)){
            return BRAKE;
        }

        List<String> collect = result.stream().map(Item::toString).collect(Collectors.toList());
        return String.join(COMMA, collect);
    }

    /**
     * Appends the string representation of a list of {@code Item} objects into the provided StringBuilder.
     * The appended string will be followed by a new line.
     *
     * @param resultStringBuilder the StringBuilder to which the string representation will be appended.
     * @param result the list of {@code Item} objects to be converted and appended.
     */
    public static void append(StringBuilder resultStringBuilder, List<Item> result) {
        resultStringBuilder.append(ItemStringConverter.toResultString(result)).append(NEW_LINE);
    }
}

