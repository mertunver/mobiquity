package com.mobiquity.helper;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

/**
 * Utility class for parsing lines into their respective components.
 * This class provides static methods to parse capacity and items from the given lines.
 */
public class LineParser {

    /**
     * Parses the given line to extract capacity as a double.
     *
     * @param line the line to be parsed, expecting a format where the capacity is before a colon.
     * @return the parsed capacity as a double.
     * @throws APIException if the line format is incorrect or the capacity cannot be parsed.
     */
    public static double parseCapacity(String line) throws APIException {
        try {
            String[] parts = line.split(":"); // Split the line using the colon
            return Double.parseDouble(parts[0].trim()); // Convert the string before the colon to a double
        } catch (Exception e) {
            throw new APIException("invalid capacity in line " + line, e);
        }
    }

    /**
     * Parses the given line to extract a list of {@code Item} objects.
     *
     * @param line the line to be parsed, expecting it to match the ITEM_PATTERN for each item.
     * @return a list of {@code Item} objects extracted from the given line.
     */
    public static List<Item> parseItems(String line) {
        List<Item> items = new ArrayList<>();
        Matcher matcher = Item.ITEM_PATTERN.matcher(line);

        while (matcher.find()) {
            int index = Integer.parseInt(matcher.group(1));
            double weight = Double.parseDouble(matcher.group(2));
            double cost = Double.parseDouble(matcher.group(3));
            items.add(new Item(index, weight, cost));
        }

        return items;
    }
}

