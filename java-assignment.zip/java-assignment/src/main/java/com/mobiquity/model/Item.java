package com.mobiquity.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.regex.Pattern;


/**
 * Represents an item with specific properties such as index, weight, and cost.
 * This class provides a static pattern for item parsing and a method for string representation of the item's index.
 */
@Builder
@Data
@AllArgsConstructor
public class Item {

    /** Pattern used for parsing item details from a formatted string. */
    public static final Pattern ITEM_PATTERN = Pattern.compile("\\((\\d+),(\\d+\\.\\d+),€(\\d+)\\)");

    /** Index of the item. */
    private Integer index;

    /** Weight of the item. */
    private Double weight;

    /** Cost of the item. */
    private Double cost;

    // Assuming you'll have constructors, getters, and setters; they should have Javadocs too.

    /**
     * Returns a string representation of the item's index.
     *
     * @return a string representation of the index.
     */
    @Override
    public String toString() {
        return String.valueOf(this.getIndex());
    }
}


