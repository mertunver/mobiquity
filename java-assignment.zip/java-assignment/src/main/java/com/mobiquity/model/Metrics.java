package com.mobiquity.model;

import lombok.Data;

/**
 * Represents metrics concerning cost and combination weight.
 * This class holds two fields: one for tracking the maximum cost and another for tracking the minimum combination weight.
 */
@Data
public class Metrics {

    /** Maximum cost among the considered items or combinations. */
    public double maxCost = 0;

    /** Minimum weight for a combination of items. Initialized to the largest positive finite value of type double. */
    public double minComboWeight = Double.MAX_VALUE;

    // If you add constructors, methods, or any other components, ensure they have Javadoc comments as well.
}

