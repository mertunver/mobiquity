package com.mobiquity.packer;

import com.mobiquity.exception.APIException;
import com.mobiquity.helper.ItemStringConverter;
import com.mobiquity.helper.LineParser;
import com.mobiquity.model.Item;
import com.mobiquity.model.Metrics;
import com.mobiquity.util.FileReader;
import com.mobiquity.validator.ItemValidator;
import com.mobiquity.validator.PackageCapacityValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
/**
 * Provides functionality to determine the best packing of items based on their weight and cost.
 * The goal is to maximize the cost within a given weight capacity.
 */
public class Packer {
    /**
     * Private constructor to prevent instantiation of the utility class.
     */
    private Packer() {
    }

    /**
     * Packs the items from a file located at the provided file path. The method reads the file,
     * parses lines to extract capacity and items, validates them, and determines the best packing.
     *
     * @param filePath the path to the input file.
     * @return a string representation of the best packing for each line in the file.
     * @throws APIException if there's an error in reading the file, parsing the lines, or in validation.
     */
    public static String pack(String filePath) throws APIException {
        ArrayList<String> lines = FileReader.readFile(filePath);

        return getResult(lines);
    }

    /**
     * Processes the provided lines to determine the best packing.
     *
     * @param lines the lines to be processed.
     * @return a string representation of the best packing for each line.
     * @throws APIException if there's an error in parsing the lines or in validation.
     */
    private static String getResult(ArrayList<String> lines) throws APIException {
        StringBuilder resultStringBuilder= new StringBuilder();

        for (String line : lines) {
            double capacity = LineParser.parseCapacity(line);
            List<Item> items = LineParser.parseItems(line);

            ItemValidator.validateItems(items);
            PackageCapacityValidator.validate(capacity);

            List<Item> result = getBestItems(items, capacity);

            ItemStringConverter.append(resultStringBuilder, result);
        }
        return resultStringBuilder.toString();
    }

    /**
     * Determines the best items to pack based on their weight and cost.
     *
     * @param allItems the list of all available items.
     * @param capacity the maximum allowed weight.
     * @return a list of the best items to pack.
     */
    private static List<Item> getBestItems(List<Item> allItems, double capacity) {
        List<Item> bestItems = new ArrayList<>();
        Metrics metrics = new Metrics();

        for (int i = 0; i < allItems.size(); i++) {
            Item currentItem = allItems.get(i);

            // Evaluate the current item alone
            updateBestItems(bestItems, List.of(currentItem), metrics, capacity);

            List<Item> currentCombo = new ArrayList<>();
            currentCombo.add(currentItem);

            for (int j = i + 1; j < allItems.size(); j++) {
                Item nextItem = allItems.get(j);
                List<Item> newCombo = new ArrayList<>(currentCombo);
                newCombo.add(nextItem);

                updateBestItems(bestItems, newCombo, metrics, capacity);
            }
        }

        return bestItems;
    }

    /**
     * Updates the best items list based on a combination of items and their total weight and cost.
     * It will replace the current best items if the new combination has a higher cost or has the
     * same cost but a lesser weight, considering the capacity constraint.
     *
     * @param bestItems the current list of best items.
     * @param combo the current combination of items.
     * @param metrics metrics to track the maximum cost and minimum combination weight.
     * @param capacity the maximum allowed weight.
     */
    private static void updateBestItems(List<Item> bestItems, List<Item> combo, Metrics metrics, double capacity) {
        double comboWeight = combo.stream().mapToDouble(Item::getWeight).sum();
        double comboCost = combo.stream().mapToDouble(Item::getCost).sum();

        if (comboWeight <= capacity && (comboCost > metrics.maxCost || (comboCost == metrics.maxCost && comboWeight < metrics.minComboWeight))) {
            bestItems.clear();
            bestItems.addAll(combo);
            metrics.maxCost = comboCost;
            metrics.minComboWeight = comboWeight;
        }
    }
}
