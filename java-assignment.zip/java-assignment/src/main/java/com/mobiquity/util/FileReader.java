package com.mobiquity.util;

import com.mobiquity.exception.APIException;

import java.io.*;
import java.util.ArrayList;

/**
 * Utility class for reading contents of a file.
 * Provides functionality to read a file and return its content as a list of strings.
 */
public class FileReader {

    /**
     * Reads a file located at the specified file path and returns its content as a list of strings.
     *
     * @param filePath the path to the input file.
     * @return an {@code ArrayList<String>} containing the lines of the file.
     * @throws APIException if an error occurs while reading the file.
     */
    public static ArrayList<String> readFile(String filePath) throws APIException {
        ArrayList<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new java.io.FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            throw new APIException("error occurred while reading data", e);
        }

        return lines;
    }
}
