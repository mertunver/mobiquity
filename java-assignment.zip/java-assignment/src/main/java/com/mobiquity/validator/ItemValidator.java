package com.mobiquity.validator;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;

import java.util.List;

/**
 * Utility class responsible for validating items based on predefined constraints.
 * Provides functionality to validate both individual items and a list of items.
 */
public class ItemValidator {

    /** The maximum allowed cost for an item. */
    public static final double MAX_COST = 100;

    /** The maximum allowed weight for an item. */
    public static final double MAX_WEIGHT = 100;

    /**
     * Validates the provided item against certain criteria:
     * - The item itself shouldn't be null.
     * - Its weight, cost, and index shouldn't be null.
     * - The item's cost should not exceed the maximum allowed cost.
     * - The item's weight should not exceed the maximum allowed weight.
     *
     * @param item The item to be validated.
     * @throws APIException if the item fails any of the validation criteria.
     */
    public static void validate(Item item) throws APIException {
        if (item == null) {
            throw new APIException("packageItem is null");
        }

        if (item.getWeight() == null) {
            throw new APIException("packageItem weight is null");
        }

        if (item.getCost() == null) {
            throw new APIException("packageItem cost is null");
        }

        if (item.getIndex() == null) {
            throw new APIException("packageItem index is null");
        }

        if (item.getCost() > MAX_COST) {
            throw new APIException("packageItem should be less than or equal to " + MAX_COST + " cost is: " + item.getCost());
        }

        if (item.getWeight() > MAX_WEIGHT) {
            throw new APIException("packageItem should be less than or equal to " + MAX_WEIGHT + " weight is:" + item.getWeight());
        }
    }

    /**
     * Validates each item in the provided list using the {@link #validate(Item)} method.
     *
     * @param items The list of items to be validated.
     * @throws APIException if any item in the list fails the validation.
     */
    public static void validateItems(List<Item> items) throws APIException {
        for (Item item : items) {
            ItemValidator.validate(item);
        }
    }
}

