package com.mobiquity.validator;

import com.mobiquity.exception.APIException;


/**
 * Utility class responsible for validating package capacities based on predefined constraints.
 * The class provides functionality to ensure that the package's weight capacity does not exceed a maximum allowable limit.
 */
public class PackageCapacityValidator {

    /** The maximum allowed weight capacity for a package. */
    public static final double MAX_WEIGHT_CAPACITY = 100;

    /**
     * Validates the provided package capacity against certain criteria:
     * - The capacity shouldn't be null.
     * - The package's weight capacity should not exceed the maximum allowed capacity.
     *
     * @param capacity The package capacity to be validated.
     * @throws APIException if the capacity fails any of the validation criteria.
     */
    public static void validate(Double capacity) throws APIException {
        if (capacity == null) {
            throw new APIException("capacity is null");
        }

        if (capacity > MAX_WEIGHT_CAPACITY) {
            throw new APIException("package's max weight capacity should be less than or equal to " + MAX_WEIGHT_CAPACITY + " weight is: " + capacity);
        }
    }
}
