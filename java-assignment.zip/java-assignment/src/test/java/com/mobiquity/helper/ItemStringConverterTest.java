package com.mobiquity.helper;

import com.mobiquity.model.Item;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ItemStringConverterTest {

    @Test
    void it_should_return_result_with_toResultString() {

        String expected = "1,2";

        String actual = ItemStringConverter.toResultString(List.of(
                Item.builder()
                        .cost(10.0)
                        .index(1)
                        .weight(20.0)
                        .build(),
                Item.builder()
                        .cost(10.0)
                        .index(2)
                        .weight(20.0)
                        .build()
        ));

        assertEquals(expected, actual);
    }

    @Test
    void it_should_return_result_with_append() {

        StringBuilder strBuilder = new StringBuilder();
        String expected = "1,2\n";

        ItemStringConverter.append(strBuilder, List.of(
                Item.builder()
                        .cost(10.0)
                        .index(1)
                        .weight(20.0)
                        .build(),
                Item.builder()
                        .cost(10.0)
                        .index(2)
                        .weight(20.0)
                        .build()
        ));

        assertEquals(expected, strBuilder.toString());
    }
}