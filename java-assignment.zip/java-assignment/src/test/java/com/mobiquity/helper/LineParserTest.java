package com.mobiquity.helper;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class LineParserTest {

    @Test
    @SneakyThrows
    void it_should_parse_capacity() {
        String testLine = "8 : (1,15.3,€34)";
        double expectedCapacity = 8;
        double actualCapacity = LineParser.parseCapacity(testLine);

        assertEquals(expectedCapacity, actualCapacity);
    }

    @Test
    @SneakyThrows
    void it_should_throws_exception_when_invalid_capacity_line() {
        String testLine = ": (1,15.3,€34)";
        assertThrows(APIException.class, () -> LineParser.parseCapacity(testLine));
    }

    @Test
    @SneakyThrows
    void it_should_parse_items() {
        String testLine = "81 : (1,20.0,€30) (2,20.0,€30)";

        List<Item> expectedItems = List.of(Item.builder()
                        .index(1)
                        .weight(20.0)
                        .cost(30.0)
                        .build(),
                Item.builder()
                        .index(2)
                        .weight(20.0)
                        .cost(30.0)
                        .build());

        List<Item> actualItems = LineParser.parseItems(testLine);

        assertEquals(expectedItems, actualItems);
    }

    @Test
    @SneakyThrows
    void it_should_throws_exception_when_line_is_invalid_item_line() {
        String testLine = "--";

        List<Item> expectedItems = List.of();

        List<Item> actualItems = LineParser.parseItems(testLine);

        assertEquals(expectedItems, actualItems);
    }

}