package com.mobiquity.packer;

import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PackerTest {

    @Test
    @SneakyThrows
    void it_should_return_best_items(){
        String expectedResult =
                "4\n" +
                "-\n" +
                "2,7\n" +
                "8,9" +
                "\n";

        String actualResult = Packer.pack("src/main/test/resources/example_input");

        assertEquals(expectedResult,actualResult);
    }
}