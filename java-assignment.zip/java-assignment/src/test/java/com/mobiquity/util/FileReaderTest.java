package com.mobiquity.util;

import com.mobiquity.exception.APIException;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


class FileReaderTest {

    @Test
    @SneakyThrows
    void it_should_readFile() {
        ArrayList<String> expectedLines = new ArrayList<>();
        expectedLines.add("81 : (1,53.38,€45) (2,88.62,€98) (3,78.48,€3) (4,72.30,€76) (5,30.18,€9) (6,46.34,€48)");
        expectedLines.add("8 : (1,15.3,€34)");

        ArrayList<String> lines = FileReader.readFile("src/test/java/resources/example_test_input");

        assertEquals(lines.toString(), expectedLines.toString());
    }

    @Test
    @SneakyThrows
    void it_should_throws_exception_when_path_is_not_valid() {
        assertThrows(APIException.class, () -> FileReader.readFile("notValidPath"));
    }

}