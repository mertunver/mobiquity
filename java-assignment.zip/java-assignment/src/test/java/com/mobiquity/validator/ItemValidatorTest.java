package com.mobiquity.validator;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ItemValidatorTest {

    public static final double COST = 20.0;
    public static final int INDEX = 1;
    public static final double WEIGHT = 10.0;
    public static final double EXCEED_MAX_COST = 101.0;
    public static final double EXCEED_MAX_WEIGHT = 101.0;

    @Test
    void it_should_throws_exception_when_item_is_null(){
        assertThrows(APIException.class, () -> ItemValidator.validate(null));
    }

    @Test
    void it_should_throws_exception_when_item_weight_is_null(){

        assertThrows(APIException.class, () -> ItemValidator.validate(Item.builder().index(INDEX).cost(COST).build()));
    }

    @Test
    void it_should_throws_exception_when_item_cost_is_null(){

        assertThrows(APIException.class, () -> ItemValidator.validate(Item.builder().index(INDEX).weight(WEIGHT).build()));
    }

    @Test
    void it_should_throws_exception_when_item_index_is_null(){

        assertThrows(APIException.class, () -> ItemValidator.validate(Item.builder().weight(WEIGHT).cost(COST).build()));
    }

    @Test
    void it_should_throws_exception_when_item_cost_exceed_max_cost(){

        assertThrows(APIException.class, () -> ItemValidator.validate(Item.builder().weight(WEIGHT).cost(EXCEED_MAX_COST).index(INDEX).build()));
    }

    @Test
    void it_should_throws_exception_when_item_weight_exceed_max_weight(){

        assertThrows(APIException.class, () -> ItemValidator.validate(Item.builder().weight(EXCEED_MAX_WEIGHT).cost(COST).index(INDEX).build()));
    }
}