package com.mobiquity.validator;

import com.mobiquity.exception.APIException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class PackageCapacityValidatorTest {

    public static final double EXCEED_MAX_WEIGHT_CAPACITY = 101;

    @Test
    void it_should_throws_exception_when_capacity_is_null() {

        assertThrows(APIException.class, () -> PackageCapacityValidator.validate(null));

    }

    @Test
    void it_should_throws_exception_when_package_weight_exceed_max_weight() {

        assertThrows(APIException.class, () -> PackageCapacityValidator.validate(EXCEED_MAX_WEIGHT_CAPACITY));
    }

}